#ifndef _CODEX_KERNEL_H
#define _CODEX_KERNEL_H

#include <linux/types.h>

#define CODEX_TOKEN_PATH "/data/vendor/codex-responses/oauth.json"
#define CODEX_TOKEN_DIR  "/data/vendor/codex-responses"

#define CODEX_ACCESS_TOKEN_MAX  16384
#define CODEX_REFRESH_TOKEN_MAX 16384
#define CODEX_ID_TOKEN_MAX      16384
#define CODEX_ACCOUNT_ID_MAX    192
#define CODEX_OAUTH_URL_MAX     4096
#define CODEX_ERROR_MAX         384
#define CODEX_RESPONSE_ID_MAX   192
#define CODEX_RESPONSE_MAX      (512 * 1024)
#define CODEX_HTTP_MAX          (8 * 1024 * 1024)

struct codex_session {
    char access_token[CODEX_ACCESS_TOKEN_MAX];
    char refresh_token[CODEX_REFRESH_TOKEN_MAX];
    char id_token[CODEX_ID_TOKEN_MAX];
    char account_id[CODEX_ACCOUNT_ID_MAX];
    s64 expires_at_epoch_seconds;
};

struct codex_message {
    const char *role;
    const char *text;
};

int codex_token_store_save(const struct codex_session *session);
int codex_token_store_load(struct codex_session *session);
int codex_token_store_delete(void);

int codex_oauth_begin(char *url, size_t url_cap);
int codex_oauth_refresh(struct codex_session *session);
int codex_oauth_refresh_if_needed(struct codex_session *session);
int codex_oauth_status(struct codex_session *session);
const char *codex_oauth_last_error(void);

int codex_responses_send(const char *instructions,
                         const struct codex_message *history,
                         size_t history_count,
                         const char *user_message,
                         const char *reasoning_effort,
                         char *reply,
                         size_t reply_cap,
                         char *response_id,
                         size_t response_id_cap);

/* Internal HTTPS primitive implemented in codex_oauth.c and shared by
 * OAuth and Responses.  Returned body is allocated with kvmalloc(); caller
 * releases it with kvfree(). */
int codex_https_post(const char *host,
                     const char *path,
                     const char *extra_headers,
                     const void *body,
                     size_t body_len,
                     unsigned char **response_body,
                     size_t *response_len,
                     int *http_status);

#endif
